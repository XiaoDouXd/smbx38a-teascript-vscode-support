素材图集命名规则：``torrent_{类型}_{*}``

- cor - 转折：``torrent_cor_{进入的水流方向}{离开的水流方向}``
- edge - 边缘：``torrent_edge_{水流方向}_{边缘之于水流方向的相对位置}``
- edge - 边角：``torrent_edge_cor_{水流方向}_{边角之余水流方向的相对方位}``
- surf - 表面：``torrent_surf_{水流方向}``

> 小豆作品 made by xiaodou