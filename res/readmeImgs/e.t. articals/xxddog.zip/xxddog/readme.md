本图集适配路易吉的 sprite 切图格式

> 小豆作品 made by xiaodou